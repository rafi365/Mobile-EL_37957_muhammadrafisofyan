package com.umn.ac.id.muhammadrafisofyan_00000037957_if570_el_uts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.LinkedList;

public class AudioList extends AppCompatActivity {

    RecyclerView iniRv;
    AudiolistAdapter rvAdapter;
    LinkedList<audioarray> audiodb = new LinkedList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_list);
        Intent intent = getIntent();
        String nama = intent.getStringExtra("extras");
        getSupportActionBar().setTitle(nama);
        Toast.makeText(this, "Selamat Datang, "+nama, Toast.LENGTH_LONG).show();

        makedb();//create list of audio data

        iniRv = findViewById(R.id.iniRv);
        rvAdapter = new AudiolistAdapter(this, audiodb);
        iniRv.setAdapter(rvAdapter);
        iniRv.setLayoutManager(new LinearLayoutManager(this));
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.librarymenu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.profile:
                Intent intentSatu = new Intent(this, Profile.class);
                startActivity(intentSatu);
                return true;
            case R.id.homepage:
                Intent intentDua = new Intent(this, MainActivity.class);
                startActivity(intentDua);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void makedb() {
        audiodb.add(new audioarray("Swoosh","SFX","android.resource://" +getPackageName() + "/"+ R.raw.swoosh02));
        audiodb.add(new audioarray("Electric","SFX","android.resource://" +getPackageName() + "/"+ R.raw.electric));
        audiodb.add(new audioarray("Gunshow","SFX","android.resource://" +getPackageName() + "/"+ R.raw.gunshot));
        audiodb.add(new audioarray("Glitch","glitchy","android.resource://" +getPackageName() + "/"+ R.raw.glitch));
        audiodb.add(new audioarray("Splat","SFX","android.resource://" +getPackageName() + "/"+ R.raw.splat));
        audiodb.add(new audioarray("Wind","SFX","android.resource://" +getPackageName() + "/"+ R.raw.wind));
    }
}