package com.umn.ac.id.muhammadrafisofyan_00000037957_if570_el_uts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class AudioViewer extends AppCompatActivity {
    TextView title;
    TextView desc;
    Button playbutton;
    MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_viewer);
        Intent intent = getIntent();
        audioarray audiodetails = (audioarray) intent.getExtras().getSerializable("extras");
        getSupportActionBar().setTitle(audiodetails.getTitle());
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        title = findViewById(R.id.title);
        desc = findViewById(R.id.desc);
        playbutton = findViewById(R.id.button);
        title.setText(audiodetails.getTitle());
        desc.setText(audiodetails.getDesc());
        mediaPlayer = MediaPlayer.create(this, Uri.parse(audiodetails.getAudioURI()));
        playbutton.setOnClickListener(view -> {
            mediaPlayer.start();
        });

    }

    @Override
    protected void onStop() {
        super.onStop();
        mediaPlayer.release();
        mediaPlayer = null;
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}