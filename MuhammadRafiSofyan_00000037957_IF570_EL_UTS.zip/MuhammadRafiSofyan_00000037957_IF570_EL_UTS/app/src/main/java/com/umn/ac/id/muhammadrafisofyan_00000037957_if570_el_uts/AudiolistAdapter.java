package com.umn.ac.id.muhammadrafisofyan_00000037957_if570_el_uts;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.LinkedList;

public class AudiolistAdapter extends RecyclerView.Adapter<AudiolistAdapter.IniViewHolder> {
    private LayoutInflater inflater;
    private LinkedList<audioarray> audiodb;
    private Context mContext;


    AudiolistAdapter(Context context, LinkedList<audioarray> list){
        inflater = LayoutInflater.from(context);
        audiodb = list;
        this.mContext = context;
    }

    @NonNull
    @Override
    public IniViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.itemtemplate, parent, false);
        return new IniViewHolder(view, this);
    }

    @Override
    public void onBindViewHolder(@NonNull IniViewHolder holder, int position) {
        holder.tvRv.setText(audiodb.get(position).getTitle());
        holder.desc.setText(audiodb.get(position).getDesc());
    }

    @Override
    public int getItemCount() {
        return audiodb.size();
    }
    public class IniViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView tvRv;
        TextView desc;
        AudiolistAdapter iniAdapter;
        ImageView delbtn;
        private int mPosisi;
        private audioarray mSumberAudio;
        public IniViewHolder(@NonNull View itemView, AudiolistAdapter adapter) {
            super(itemView);
            tvRv = itemView.findViewById(R.id.tvRv);
            desc = itemView.findViewById(R.id.details);
            iniAdapter = adapter;
            delbtn = itemView.findViewById(R.id.deletebtn);
            delbtn.setOnClickListener(view -> {
                mPosisi = getLayoutPosition();
//                String testc = daftarNama.get(mPosisi);
//                Toast.makeText(mContext, testc, Toast.LENGTH_LONG).show();
                audiodb.remove(mPosisi);//remove the item from list
                notifyItemRemoved(mPosisi);//refresh recyclerview
            });
            itemView.setOnClickListener(this);//enable onclick view
        }
        @Override
        public void onClick(View v) {
            mPosisi = getLayoutPosition();
            mSumberAudio = audiodb.get(mPosisi);
            Intent intentSatu = new Intent(mContext, AudioViewer.class);
            intentSatu.putExtra("extras", mSumberAudio);
            mContext.startActivity(intentSatu);
        }
    }
}
