package com.umn.ac.id.muhammadrafisofyan_00000037957_if570_el_uts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LoginPage extends AppCompatActivity {

    Button loginbutton;
    EditText nameinput;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);
        getSupportActionBar().hide();

        loginbutton = findViewById(R.id.button);
        nameinput = findViewById(R.id.editTextTextPersonName);
        loginbutton.setOnClickListener(v ->{
            changescene();
        });
    }
    public void changescene(){
        String textname = nameinput.getText().toString();
        if(textname.isEmpty()){
            nameinput.setError("Harap Di-isi");
        }else{
            Intent intentSatu = new Intent(this, AudioList.class);
            intentSatu.putExtra("extras", textname);
            startActivity(intentSatu);
        }
    }
}