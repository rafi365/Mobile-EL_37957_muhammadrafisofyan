package com.umn.ac.id.muhammadrafisofyan_00000037957_if570_el_uts;

import java.io.Serializable;

public class audioarray implements Serializable {
    private String title;
    private String desc;
    private String audioURI;
    public audioarray(String title, String desc,
                      String audioURI){
        this.title = title;
        this.desc = desc;
        this.audioURI = audioURI;
    }

    public String getTitle()        { return this.title;        }
    public String getDesc()   { return this.desc;   }
    public String getAudioURI()     { return this.audioURI;     }

    public void setTitle(String title){ this.title = title;    }
    public void setDesc(String desc) {
        this.desc = desc;
    }
    public void setAudioURI(String audioURI) {
        this.audioURI = audioURI;
    }
    public String toString() { return this.getTitle() + " => "
            + this.getDesc(); }
}
